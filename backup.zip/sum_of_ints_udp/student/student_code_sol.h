#ifndef __STUDENT_CODE_SOL_H__
#define __STUDENT_CODE_SOL_H__

#include <stdint.h>

int get_sum_of_ints_udp_sol(int sockfd, uint32_t *tab, size_t length, uint32_t *rep);

int server_udp_sol(int sockfd);

#endif // __STUDENT_CODE_SOL_H__

